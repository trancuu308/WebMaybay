﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;

namespace Lab01.Controllers
{
    public class DetailController : Controller
    {
        // GET: Detail
        Online_ShopEntities _database = new Online_ShopEntities();
            // GET: Product/Details/5
            public ActionResult Index(int id)
            {
                return View(_database.Flights.Where(s => s.IDFlight == id).FirstOrDefault());
            }
       
    }
}