﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using Lab01.Session;

namespace Lab01.Controllers
{
    public class LoginController : Controller
    {

        Online_ShopEntities _db = new Online_ShopEntities();
        // GET: Login
        public ActionResult Index()
        {
            ViewBag.LoginError = TempData["LoginError"];
            return View();
        }
        [HttpPost]
        public ActionResult Index(string account, string password)
        {
            var user = _db.Users.Where(m => m.Email == account && m.Password == password).FirstOrDefault();
            if (account != null && password != null && user != null)
            {
                    Session.Add(GLOBAL_SESSION.USER_SESSION, user);
                var cart = Session[GLOBAL_SESSION.CART] as Cart;
                if (cart != null)
                {
                    return RedirectToAction("CheckOut", "ShoppingCart");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
               
            }
            ViewBag.Error = "Email or password is incorrect. Please reenter!";
            return View();
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(RegisterViewModel registerViewModel)
        {
            if (ModelState.IsValid)
            {
                if (registerViewModel.RePassword != registerViewModel.User.Password)
                {
                    ViewBag.ErrorPassword = "Password and Repassword must be the same";
                    return View();
                }
                registerViewModel.User.Email = registerViewModel.Customer.Email_Cus;
                _db.Users.Add(registerViewModel.User);
                _db.Customers.Add(registerViewModel.Customer);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult LogOut()
        {
            Session.Abandon();
            return RedirectToAction("Index", "LogIn"); // me thod login laf index
        }

    }
}