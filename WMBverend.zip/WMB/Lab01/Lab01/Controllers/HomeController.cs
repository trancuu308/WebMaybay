﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using PagedList;
namespace Lab01.Controllers
{
    public class HomeController : Controller
    {
        Online_ShopEntities _db =  new Online_ShopEntities();
        // GET: Home
        public ActionResult Index()
        {
            return View();
           
        }

        public PartialViewResult FooterByAirlines()
        {
            var lstAirlines = _db.Airlines.ToList();
            ViewBag.lstAirlines = lstAirlines;
            return PartialView();
        }

        public PartialViewResult FooterByDestination()
        { 
            var lstFlight = _db.CitiesTables.ToList();
            ViewBag.lstFlight = lstFlight;
  
            return PartialView();
        }

        public PartialViewResult SearchForm()
        {
            if (TempData["abc"] == null)
            {
                ViewBag.CurrentFilter = new Flight()
                {
                    From = 0,
                    To = 0
                };
            }
            else
            {
                string currentFilter = TempData["abc"] as string;
                if (!string.IsNullOrEmpty(currentFilter))
                {
                    string[] arrString = currentFilter.Split(';');
                    if (!string.IsNullOrEmpty(arrString[2]) && arrString[3] == "")
                    {
                        ViewBag.CurrentFilter = new Flight()
                        {
                            From = Int32.Parse(arrString[0]),
                            To = Int32.Parse(arrString[1]),
                            TimeEnd = DateTime.Parse(arrString[2])
                            
                        };
                    }
                    else if (!string.IsNullOrEmpty(arrString[3]) && arrString[2] == "")
                    {
                        ViewBag.CurrentFilter = new Flight()
                        {
                            From = Int32.Parse(arrString[0]),
                            To = Int32.Parse(arrString[1]),
                            TimeStart = DateTime.Parse(arrString[3])
                        };
                    }
                    else if (string.IsNullOrEmpty(arrString[0]) && string.IsNullOrEmpty(arrString[1]) &&
                             string.IsNullOrEmpty(arrString[2]) && string.IsNullOrEmpty(arrString[3]))
                    {
                        ViewBag.CurrentFilter = new Flight()
                        {
                            From = null,
                            To = null
                        };
                    }
                    else if (string.IsNullOrEmpty(arrString[3]) && arrString[2] == "")
                    {
                        ViewBag.CurrentFilter = new Flight()
                        {
                            From = Int32.Parse(arrString[0]),
                            To = !string.IsNullOrEmpty(arrString[1]) ? Int32.Parse(arrString[1]) : 0
                        };
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(arrString[0]) && string.IsNullOrEmpty(arrString[1]) &&
                            string.IsNullOrEmpty(arrString[2]) && string.IsNullOrEmpty(arrString[3]))
                        {
                            ViewBag.CurrentFilter = new Flight()
                            {
                                From = 0,
                                To = 0
                            };
                        }
                        else
                        {
                          
                            ViewBag.CurrentFilter = new Flight()
                            {
                                From = Int32.Parse(arrString[0]),
                                To = Int32.Parse(arrString[1]),
                                TimeEnd = DateTime.Parse(arrString[2]),
                                TimeStart = DateTime.Parse(arrString[3])
                            };
                          
                        }
                      
                    }
                   
                }
            }

            var destination = _db.CitiesTables.ToList();
            Dictionary<int, string> dicFrom = new Dictionary<int, string>();
            dicFrom.Add(0, "---Chọn Điểm Đến---");
       
            foreach (var foo in destination)
            {
                dicFrom.Add(foo.ID, foo.CityName);
            }

            var destination2 = _db.CitiesTables.ToList();
            Dictionary<int, string> dicTo = new Dictionary<int, string>();
            dicTo.Add(0, "---Chọn Điểm Đi---");

            foreach (var foo in destination)
            {
                dicTo.Add(foo.ID, foo.CityName);
            }


            var currentFilterr = ViewBag.CurrentFilter as Flight;
            ViewBag.ListFrom = dicFrom;
            ViewBag.ListTo = dicTo;

            return PartialView(currentFilterr);

        }

        //public ActionResult Lichsumuahang(string currentFilter, string searchString, int? page)
        //{
        //    if (searchString != null)
        //    {
        //        page = 1;
        //    }
        //    else
        //    {
        //        searchString = currentFilter;
        //    }
        //    ViewBag.CurrentFilter = searchString;

        //    var orderDetails = from s in _db.OrderDetails
        //                       select s;
        //    if (!String.IsNullOrEmpty(searchString))
        //    {
        //        orderDetails = orderDetails.Where(s => s.Flight.TimeStart.Value.Month.ToString() == searchString);
        //    }
        //    int pageSize = 6;
        //    int pageNumber = (page ?? 1);
        //    var lstFlight = orderDetails.ToList();
        //    int totalQuantity = 0;
        //    decimal totalPrice = 0;
        //    foreach (var orderDetail in lstFlight)
        //    {
        //        totalQuantity += orderDetail.Quantity.Value;
        //        totalPrice += (orderDetail.Quantity.Value * orderDetail.UnitPriceSale.Value);
        //    }

        //    ViewBag.TotalQuantity = totalQuantity;
        //    ViewBag.TotalPrice = totalPrice;
        //    //
        //    return View(orderDetails.OrderBy(x => x.ID).ToPagedList(pageNumber, pageSize));
        //}
    }
}