﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using Lab01.Session;

namespace Lab01.Controllers
{
    public class ShoppingCartController : Controller
    {


        private readonly Online_ShopEntities context = new Online_ShopEntities();
        public ActionResult Index()
        {
            ViewBag.LoiSoLuong = TempData["LoiSoLuong"] as string;
            ViewBag.ThongBaoTrong = TempData["ThongBaoTrong"] as string;
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            Cart listItem = new Cart();
            if (cart != null && cart.Items.Count > 0)
            {
                listItem = cart;
            }
            else
            {
                listItem.Items = new List<CartItem>();
                ViewBag.GioHangTrong = "Hiện tại quý khách chưa chọn vé, mời quý khách lựa chọn vé !!";
            }

            return View(listItem);
        }
        [HttpPost]
        public ActionResult Increase(int id, int currentQtt = 1, int quantity = 1)
        {
            var f = context.Flights.FirstOrDefault(m => m.IDFlight == id);
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            foreach (var item in cart.Items)
            {
                if (item._shopping_product.IDFlight == f.IDFlight)
                {
                    if (currentQtt < f.Quantity)
                        item._shopping_quantity += quantity;
                    else
                    {
                        TempData["LoiSoLuong"] = "<script>alert('Vé tạm hết, vui lòng chọn vé khác hoặc liên hệ đường dây nóng');</script>";
                        return RedirectToAction("Index");
                    }
                    //TODO
                }
            }
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult Decrease(int id, int quantity, int currentQtt)
        {

            var f = context.Flights.FirstOrDefault(m => m.IDFlight == id);
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            foreach (var item in cart.Items)
            {
                if (item._shopping_product.IDFlight == f.IDFlight)  
                {
                    if (currentQtt > 1) 
                        item._shopping_quantity -= quantity; 
                    else 
                    {
                        TempData["LoiSoLuong"] = "<script>alert('Không thể đặt  với số lượng là 0');</script>"; 
                    }
                    //TODO
                }
            }
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");


        }
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            cart.Items.RemoveAll(x => x._shopping_product.IDFlight == id);
            Session[GLOBAL_SESSION.CART] = cart;
            return RedirectToAction("Index");
        }
        public ActionResult Add(int id, int quantity)
        {
            var cart = Session[GLOBAL_SESSION.CART] as Cart;
            var f = context.Flights.FirstOrDefault(x => x.IDFlight == id);
            if (cart != null)
            {
                var listItem = cart.Items as List<CartItem>;
                if (listItem.Exists(m => m._shopping_product.IDFlight == id))
                {
                    foreach (var item in listItem)
                    {
                        if (item._shopping_product.IDFlight == f.IDFlight)
                        {
                            if (item._shopping_quantity < f.Quantity)
                                item._shopping_quantity += quantity;
                            else
                            {
                                TempData["LoiSoLuong"] = "<script>alert('Vé tạm hết, vui lòng chọn vé khác hoặc liên hệ đường dây nóng');</script>";
                                return RedirectToAction("Index", "Home");
                            }
                            //TODO
                        }
                    }
                }
                else
                {
                    CartItem cItem = new CartItem { _shopping_product = f, _shopping_quantity = quantity };
                    listItem.Add(cItem);
                }
                cart.Items = listItem;
                Session[GLOBAL_SESSION.CART] = cart;
            }
            else
            {
                cart = new Cart();
                List<CartItem> listItem = new List<CartItem>();
                CartItem cItem = new CartItem();
                if(f.Quantity < quantity)
                {
                    TempData["LoiSoLuong"] = "<script>alert('Vé tạm hết, vui lòng chọn vé khác hoặc liên hệ đường dây nóng');</script>";
                    return RedirectToAction("Index", "Home");
                }
                cItem._shopping_product = f;
                cItem._shopping_quantity = quantity;
                listItem.Add(cItem);

                cart.Items = listItem;

                Session[GLOBAL_SESSION.CART] = cart;

            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult CheckOut()
        {
            User user = (User)Session[GLOBAL_SESSION.USER_SESSION];
            if (user == null)
            {
                TempData["LoginError"] = "<script>alert('Mời Đăng Nhập Để thanh toán');</script>";
                return RedirectToAction("Index", "Login");
            }
            Cart cart = (Cart)Session[GLOBAL_SESSION.CART];
            if (cart == null)
            {
                TempData["ThongBaoTrong"] = "<script>alert('Bạn Chưa Chọn Vé Nên Không Thể Thanh Toán');</script>";
                return RedirectToAction("Index");
            }
            decimal? totalAmount = 0;
            if (user != null)
            {
                ViewBag.SDT = context.Customers.Where(m => m.Email_Cus == user.Email).FirstOrDefault().Phone_Cus;
                ViewBag.Address = context.Customers.Where(m => m.Email_Cus == user.Email).FirstOrDefault().Address_Cus;
                ViewBag.User = user;

                ViewBag.Cart = cart;
                foreach (var item in cart.Items)
                {
                    totalAmount += item._shopping_quantity * item._shopping_product.UnitPrice;
                }
                TempData["ToTalAmount"] = totalAmount;
            }

            return View();
        }
        [HttpPost]
        public ActionResult CheckOut(decimal totalAmount)
        {
            User user = (User)Session[GLOBAL_SESSION.USER_SESSION];
            Cart cart = (Cart)Session[GLOBAL_SESSION.CART];
            List<OrderDetail> orderDetails = new List<OrderDetail>();
            foreach (var item in cart.Items)
            {
                
                var flight = context.Flights.FirstOrDefault(x => x.IDFlight == item._shopping_product.IDFlight);
                if (item._shopping_quantity > flight.Quantity)
                {
                    TempData["LoiSoLuong"] = "<script>alert('Vé tạm hết, vui lòng chọn vé khác hoặc liên hệ đường dây nóng');</script>";
                    return RedirectToAction("Index","Home");
                }
                flight.Quantity -= item._shopping_quantity;
                OrderDetail detail = new OrderDetail()
                {
                    IDFlight = item._shopping_product.IDFlight,
                    Quantity = item._shopping_quantity,
                    UnitPriceSale = item._shopping_product.UnitPrice
                };
                
                orderDetails.Add(detail);
            }
            Order order = new Order()
            {
                Amount = totalAmount,
                Codecus = context.Customers.Where(m => m.Email_Cus == user.Email).FirstOrDefault().CodeCus,
                Customer = context.Customers.Where(m => m.Email_Cus == user.Email).FirstOrDefault(),
                OrderDate = DateTime.Now,
                OrderDetails = orderDetails,
            };
            context.Orders.Add(order);
            context.SaveChanges();
            Session[GLOBAL_SESSION.CART] = null;
            TempData["LoiSoLuong"] = "<script>alert('Thanh Toán Thành Công');</script>";
       
            return RedirectToAction("Index","Home");
        }

    }
}