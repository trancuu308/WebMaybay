﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using PagedList;

namespace Lab01.Controllers
{
    public class TicketPlaneController : Controller
    {
        Online_ShopEntities context = new Online_ShopEntities();
        // GET: TicketPlane
        public ActionResult Index(Flight flight, int? page)
        {
            string temp = "";
            temp += flight.From.HasValue ? flight.From.ToString() : "";
            temp += ";";
            temp += flight.To.HasValue ? flight.To.ToString() : "";
            temp += ";";
            temp += flight.TimeEnd.ToString();
            temp += ";";
            temp += flight.TimeStart.ToString();
            TempData["abc"] = temp;
            var f = from s in context.Flights
                    select s;
            if (flight.IDAirlines.HasValue)
            {
                f = f.Where(x => x.IDAirlines == flight.IDAirlines);
            }
            if (flight.From != 0 && flight.To.HasValue && flight.To != 0 && flight.From != 0)
            {
                if (flight.From != 0 && flight.To != 0)
                    f = f.Where(x => x.From == flight.From && x.To == flight.To);
            }

            if (flight.From != 0 && (flight.To == 0 || !flight.To.HasValue))
            {
                if (flight.To != 0 && flight.To != null)
                    f = f.Where(x => x.To == flight.To);
            }
            if (flight.From != 0 && (flight.To == 0 || !flight.To.HasValue))
            {
                if (flight.From != 0 && flight.From!=null)
                    f = f.Where(x => x.From == flight.From);
            }
           

            if (flight.TimeStart.HasValue && flight.TimeEnd.HasValue)
            {
                f = f.Where(x => x.TimeStart >= flight.TimeStart && x.TimeEnd <= flight.TimeEnd);
            }
            ViewBag.CurrentFilter = new Flight()
            {
                IDAirlines = flight.IDAirlines,
                From = flight.From,
                To = flight.To,
                TimeEnd = flight.TimeEnd ,
                TimeStart = flight.TimeStart
            };

            int pageSize = 1;
            int pageNumber = (page ?? 1);
            //
            return View(f.OrderBy(x => x.IDFlight).ToPagedList(pageNumber, pageSize));
        }
    }
}