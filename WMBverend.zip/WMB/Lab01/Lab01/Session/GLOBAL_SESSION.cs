﻿namespace Lab01.Session
{
    public class GLOBAL_SESSION
    {
        public static string USER_SESSION = "User Session";
        public static string CART = "cart";
    }
}