﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab01.Models
{
    public class RegisterViewModel
    {
        public User User { get; set; }
        public Customer Customer { get; set; }
        public string RePassword { get; set; }
    }
}