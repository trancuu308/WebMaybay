﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab01.Models
{
    public class CartItem
    {
        public Flight _shopping_product { get; set; }
        public int _shopping_quantity { get; set; }
    }
    //Gio hang
    public class Cart
    {
        public List<CartItem> Items { get; set; }
       
    }
}
