﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;

namespace Lab01.Areas.Admin.Controllers
{
    public class AirlineController : Controller
    {
        Online_ShopEntities _db = new Online_ShopEntities();
        // GET: Product
        public ActionResult Index()
        {
            return View(_db.Airlines.ToList());
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View(_db.Airlines.Where(s => s.IDAirlines==id).FirstOrDefault());
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(Airline cate)
        {
            try
            {
                // TODO: Add insert logic here
                _db.Airlines.Add(cate);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Edit/5
        [HttpGet]
        public ActionResult Edit(int id)
        {
            return View(_db.Airlines.Where(s=>s.IDAirlines==id).FirstOrDefault());
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Airline cate)
        {
            try
            {
                // TODO: Add update logic here
                _db.Entry(cate).State = System.Data.Entity.EntityState.Modified;
                _db.SaveChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            return View(_db.Airlines.Where(s => s.IDAirlines == id).FirstOrDefault());
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Airline cate)
        {
            try
            {
                // TODO: Add delete logic here
                cate = _db.Airlines.Where(s => s.IDAirlines == id).FirstOrDefault();
                _db.Airlines.Remove(cate);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return Content("IDCategory is used for other table");
            }
        }
    }
}
