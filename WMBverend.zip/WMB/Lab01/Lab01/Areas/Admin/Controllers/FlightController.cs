﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;
using System.Data;
using System.IO;
using System.Data.Entity.Validation;
using System.Diagnostics;
using PagedList;

namespace Lab01.Areas.Admin.Controllers
{
    public class FlightController : Controller
    {
        Online_ShopEntities _database = new Online_ShopEntities();
        // GET: Product
        public ActionResult Index(string currentFilter, string searchString, int? page)
        {
           
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }

            ViewBag.CurrentFilter = searchString;

            var flights = from s in _database.Flights
                               select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                flights = flights.Where(s => s.NameFlight.Contains(searchString));
            }
            int pageSize = 6;
            int pageNumber = (page ?? 1);
            //
            return View(flights.OrderBy(x => x.IDFlight).ToPagedList(pageNumber, pageSize));
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View(_database.Flights.Where(s => s.IDFlight == id).FirstOrDefault());
        }

        // GET: Product/Create
        public ActionResult Create(string error = null)
        {
            List<Airline> cate = new List<Airline>();
            ViewBag.ListCate = _database.Airlines.ToList();
            var destination = _database.AirportsTables.ToList();
        
            Dictionary<int, string> dicFrom = new Dictionary<int, string>();
            Dictionary<int, string> dicTo = new Dictionary<int, string>();
            foreach (var foo in destination)
            {
                var cityName = _database.CitiesTables.FirstOrDefault(x => x.ID == foo.CityID).CityName;
                var name = foo.AirportName + " - " + cityName;
                dicFrom.Add((int)foo.ID, name);
            }
            //foreach (var foo in Enum.GetValues(typeof(ToEnum)))
            //{
            //    dicTo.Add((int)foo, foo.ToString());
            //}
            if (error != null)
            {
                ViewBag.Error = error;
            }
            ViewBag.ListFrom = dicFrom;
            ViewBag.ListTo = dicTo;
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(Flight pro)
        {
            if (pro.TimeStart > pro.TimeEnd)
            {
                string error = "Time start can't less time end!";
                return RedirectToAction("Create",new { error });
            }
            try
            {
                //Enum.GetValues(typeof(FromEnum));
                pro.Status = true;
                _database.Flights.Add(pro);
                _database.SaveChanges();
                return RedirectToAction("Index");

            }
            catch (DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        Trace.TraceInformation("Property: {0} Error: {1}",
                                                validationError.PropertyName,
                                                validationError.ErrorMessage);
                    }
                }
                return View();
            }

        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
        
            List<Airline> cate = new List<Airline>();
            ViewBag.ListCate = _database.Airlines.ToList();
            var destination = _database.AirportsTables.ToList();

            Dictionary<int, string> dicFrom = new Dictionary<int, string>();
            foreach (var foo in destination)
            {
                var cityName = _database.CitiesTables.FirstOrDefault(x => x.ID == foo.CityID).CityName;
                var name = foo.AirportName + " - " + cityName;
                dicFrom.Add((int)foo.ID, name);
            }
            ViewBag.ListFrom = dicFrom;
            return View(_database.Flights.Where(s => s.IDFlight == id).FirstOrDefault());
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(Flight pro)
        {
            try
            {
                _database.Entry(pro).State = System.Data.Entity.EntityState.Modified;
                _database.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Product/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_database.Flights.Where(s => s.IDFlight == id).FirstOrDefault());
        }

        // POST: Product/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Flight pro)
        {
            try
            {
                pro = _database.Flights.Where(s => s.IDFlight == id).FirstOrDefault();
                _database.Flights.Remove(pro);
                _database.SaveChanges();
                return RedirectToAction("Index");
                // TODO: Add delete logic here
            }
            catch
            {
                return View();
            }
        }
    }
}
