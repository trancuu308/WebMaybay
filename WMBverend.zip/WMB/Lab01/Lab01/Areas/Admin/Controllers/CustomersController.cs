﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Lab01.Models;

namespace Lab01.Areas.Admin.Controllers
{
    public class CustomersController : Controller
    {
        Online_ShopEntities _db = new Online_ShopEntities(); 
        // GET: Customers
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Customer cus)
        {
            _db.Customers.Add(cus);
            _db.SaveChanges();
            return RedirectToAction("ShowToCart", "ShoppingCart");
        }
    }
}