﻿using Lab01.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;

namespace Lab01.Areas.Admin.Controllers
{
    public class ThongKeController : Controller
    {
        Online_ShopEntities _database = new Online_ShopEntities();
        // GET: Admin/ThongKe
        public ActionResult Index(string currentFilter, string searchString, int? page)
        {
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewBag.CurrentFilter = searchString;

            var orderDetails = from s in _database.OrderDetails
                               select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                orderDetails = orderDetails.Where(s => s.Flight.TimeStart.Value.Month.ToString() == searchString);
            }
            int pageSize = 6;
            int pageNumber = (page ?? 1);
            var lstFlight = orderDetails.ToList();
            int totalQuantity = 0;
            decimal totalPrice = 0;
            foreach (var orderDetail in lstFlight)
            {
                totalQuantity += orderDetail.Quantity.Value;
                totalPrice += (orderDetail.Quantity.Value * orderDetail.UnitPriceSale.Value);
            }

            ViewBag.TotalQuantity = totalQuantity;
            ViewBag.TotalPrice = totalPrice;
            //
            return View(orderDetails.OrderBy(x => x.ID).ToPagedList(pageNumber, pageSize));
        }
    }
}