﻿using Lab01.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace Lab01.Areas.Admin.Controllers
{
    public class ReportController : Controller
    {
        Online_ShopEntities _database = new Online_ShopEntities();
        // GET: Admin/Report
        [HttpGet]
        public ActionResult Index(string currentFilter, string searchString, int? page)
        {
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewBag.CurrentFilter = searchString;
            
            var orderDetails = from s in _database.Orders
                     select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                orderDetails = orderDetails.Where(s => s.OrderDate.Value.Month.ToString() == searchString);
            }
            int pageSize = 6;
            int pageNumber = (page ?? 1);
            //var lstFlight = orderDetails.ToList();
            //int totalQuantity = 0;
            //decimal totalAmount = 0;
            //foreach (var orderDetail in orderDetails )
            //{
            //    totalAmount += orderDetail.Amount.Value;
                
            //}

            //ViewBag.TotalQuantity = totalQuantity;
            //ViewBag.TotalAmount = totalAmount
               
                ;
            //
            return View(orderDetails.OrderBy(x => x.Codecus).ToPagedList(pageNumber, pageSize));
        }
        
    }
}